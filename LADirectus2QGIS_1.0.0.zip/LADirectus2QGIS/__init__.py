def classFactory(iface):
    from .LADirectus2QGIS import LADirectus2QGIS
    return LADirectus2QGIS(iface)